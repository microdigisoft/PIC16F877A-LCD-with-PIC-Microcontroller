/*
 * File:   main.c
 * Author: microdigisoft.com
 *
 */
#include <xc.h>
#include "config.h"
#include "I2C.h"

void main(void) {
    
    I2C__Init();
    LCD_Init(0x4E);    // Initialize LCD module with I2C address = 0x4E
 
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("  Welcome To ");
    LCD_Set_Cursor(2, 1);  
    LCD_Write_String("  MicroDigiSoft ");
    __delay_ms(2500);

    while(1)
    {
     }
    return;
}
